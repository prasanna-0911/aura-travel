declare module 'leaflet' {
  export interface LatLngExpression {
    lat: number;
    lng: number;
  }
  
  export interface IconOptions {
    iconUrl: string;
    iconSize?: [number, number];
    iconAnchor?: [number, number];
    popupAnchor?: [number, number];
    shadowUrl?: string;
    shadowSize?: [number, number];
  }
  
  export class Icon {
    constructor(options: IconOptions);
  }
  
  export function icon(options: IconOptions): Icon;
  
  export interface DivIconOptions {
    html?: string;
    className?: string;
    iconSize?: [number, number];
    iconAnchor?: [number, number];
  }
  
  export class DivIcon {
    constructor(options: DivIconOptions);
  }
  
  export function divIcon(options: DivIconOptions): DivIcon;
}

declare module 'react-leaflet' {
  import { ReactNode } from 'react';
  
  export interface MapContainerProps {
    center: [number, number];
    zoom: number;
    style?: React.CSSProperties;
    className?: string;
    scrollWheelZoom?: boolean;
    children?: ReactNode;
  }
  
  export interface TileLayerProps {
    url: string;
    attribution?: string;
  }
  
  export interface MarkerProps {
    position: [number, number];
    icon?: L.Icon | L.DivIcon;
    children?: ReactNode;
  }
  
  export interface PopupProps {
    children?: ReactNode;
  }
  
  export interface PolylineProps {
    positions: [number, number][];
    color?: string;
    weight?: number;
    opacity?: number;
    dashArray?: string;
  }
  
  export function MapContainer(props: MapContainerProps): JSX.Element;
  export function TileLayer(props: TileLayerProps): JSX.Element;
  export function Marker(props: MarkerProps): JSX.Element;
  export function Popup(props: PopupProps): JSX.Element;
  export function Polyline(props: PolylineProps): JSX.Element;
  export function useMap(): L.Map;
}
