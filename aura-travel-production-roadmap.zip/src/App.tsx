import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Home } from '@/pages/Home';
import { Weaver } from '@/pages/Weaver';
import { LiveTrip } from '@/pages/LiveTrip';
import { Explore } from '@/pages/Explore';
import { Bookings } from '@/pages/Bookings';

export function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/weaver" element={<Weaver />} />
          <Route path="/live-trip" element={<LiveTrip />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/bookings" element={<Bookings />} />
        </Routes>
      </Layout>
    </Router>
  );
}
