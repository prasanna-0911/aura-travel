import { useEffect, useState } from 'react';
import { MapPin, Navigation, Clock, IndianRupee } from 'lucide-react';
import { Activity } from '@/data';
import { cn } from '@/utils/cn';

interface ItineraryMapProps {
  activities: {
    timeSlot: string;
    activity: Activity;
    scheduledTime: string;
  }[];
  destination: string;
  day?: number;
}

// Destination center coordinates
const DESTINATION_CENTERS: Record<string, { lat: number; lng: number; zoom: number }> = {
  'Goa': { lat: 15.4909, lng: 73.8278, zoom: 11 },
  'Manali': { lat: 32.2396, lng: 77.1887, zoom: 12 },
  'Pune': { lat: 18.5204, lng: 73.8567, zoom: 12 }
};

// Category colors for markers
const CATEGORY_COLORS: Record<string, string> = {
  leisure: '#4FA3A5',    // Eucalyptus
  cultural: '#8B5CF6',   // Purple
  adventure: '#E07A5F',  // Ember
  wellness: '#10B981',   // Green
  wildlife: '#F59E0B',   // Amber
  shopping: '#EC4899',   // Pink
  nightlife: '#6366F1',  // Indigo
};

export function ItineraryMap({ activities, destination, day }: ItineraryMapProps) {
  const [mapLoaded, setMapLoaded] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  
  const center = DESTINATION_CENTERS[destination] || DESTINATION_CENTERS['Goa'];
  
  useEffect(() => {
    // Dynamically load Leaflet CSS
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    document.head.appendChild(link);
    
    // Small delay to ensure CSS is loaded
    setTimeout(() => setMapLoaded(true), 100);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);
  
  if (!mapLoaded) {
    return (
      <div className="w-full h-[400px] bg-sandstone/30 rounded-xl flex items-center justify-center">
        <div className="text-center">
          <Navigation className="w-8 h-8 text-eucalyptus mx-auto mb-2 animate-pulse" />
          <p className="text-midnight/60">Loading map...</p>
        </div>
      </div>
    );
  }
  
  // Calculate route line
  const routePoints = activities.map(a => ({
    lat: a.activity.location.lat,
    lng: a.activity.location.lng
  }));
  
  // Calculate total distance (approximate)
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };
  
  let totalDistance = 0;
  for (let i = 0; i < routePoints.length - 1; i++) {
    totalDistance += calculateDistance(
      routePoints[i].lat, routePoints[i].lng,
      routePoints[i+1].lat, routePoints[i+1].lng
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-sandstone/50 overflow-hidden">
      {/* Map Header */}
      <div className="p-4 border-b border-sandstone/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-eucalyptus/10 rounded-lg flex items-center justify-center">
            <Navigation className="w-4 h-4 text-eucalyptus" />
          </div>
          <div>
            <h3 className="font-semibold text-midnight" style={{ fontFamily: 'var(--font-heading)' }}>
              {day ? `Day ${day} Route` : 'Trip Route'}
            </h3>
            <p className="text-sm text-midnight/60">
              {activities.length} stops • ~{totalDistance.toFixed(1)} km total
            </p>
          </div>
        </div>
        
        {/* Legend */}
        <div className="hidden md:flex items-center gap-3">
          {Object.entries(CATEGORY_COLORS).slice(0, 4).map(([category, color]) => (
            <div key={category} className="flex items-center gap-1">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: color }}
              />
              <span className="text-xs text-midnight/60 capitalize">{category}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Static Map Visualization */}
      <div 
        className="relative w-full h-[400px] bg-cover bg-center"
        style={{
          backgroundImage: `url(https://api.mapbox.com/styles/v1/mapbox/light-v11/static/${center.lng},${center.lat},${center.zoom},0/800x400@2x?access_token=pk.placeholder)`,
          backgroundColor: '#E6F2F2'
        }}
      >
        {/* Overlay for custom visualization since we can't use actual Leaflet in this environment */}
        <div className="absolute inset-0 bg-gradient-to-br from-eucalyptus/5 to-transparent">
          {/* Simulated map grid */}
          <div className="absolute inset-0" style={{
            backgroundImage: `
              linear-gradient(rgba(79, 163, 165, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(79, 163, 165, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }} />
          
          {/* Activity markers visualization */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-full h-full max-w-lg max-h-80 m-8">
              {/* Route line */}
              <svg className="absolute inset-0 w-full h-full" style={{ overflow: 'visible' }}>
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#4FA3A5" />
                  </marker>
                </defs>
                {activities.map((_, index) => {
                  if (index === activities.length - 1) return null;
                  const angle = (index * (360 / activities.length)) * Math.PI / 180;
                  const nextAngle = ((index + 1) * (360 / activities.length)) * Math.PI / 180;
                  const radius = 120;
                  const centerX = 200;
                  const centerY = 160;
                  
                  return (
                    <line
                      key={index}
                      x1={centerX + Math.cos(angle) * radius}
                      y1={centerY + Math.sin(angle) * radius}
                      x2={centerX + Math.cos(nextAngle) * radius}
                      y2={centerY + Math.sin(nextAngle) * radius}
                      stroke="#4FA3A5"
                      strokeWidth="2"
                      strokeDasharray="5,5"
                      markerEnd="url(#arrowhead)"
                    />
                  );
                })}
              </svg>
              
              {/* Markers */}
              {activities.map((item, index) => {
                const angle = (index * (360 / activities.length)) * Math.PI / 180;
                const radius = 120;
                const x = 50 + (Math.cos(angle) * radius / 4);
                const y = 50 + (Math.sin(angle) * radius / 4);
                
                return (
                  <div
                    key={index}
                    className={cn(
                      "absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 hover:scale-110 z-10",
                      selectedActivity?.id === item.activity.id && "scale-110"
                    )}
                    style={{ 
                      left: `${x}%`, 
                      top: `${y}%`,
                    }}
                    onClick={() => setSelectedActivity(
                      selectedActivity?.id === item.activity.id ? null : item.activity
                    )}
                  >
                    <div 
                      className="relative w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-lg border-2 border-white"
                      style={{ 
                        backgroundColor: CATEGORY_COLORS[item.activity.category] || '#4FA3A5'
                      }}
                    >
                      {index + 1}
                    </div>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 whitespace-nowrap">
                      <span className="text-xs font-medium text-midnight bg-white/90 px-2 py-0.5 rounded shadow-sm">
                        {item.scheduledTime}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        
        {/* Map attribution */}
        <div className="absolute bottom-2 right-2 text-xs text-midnight/40 bg-white/80 px-2 py-1 rounded">
          Interactive Map View
        </div>
      </div>
      
      {/* Activity Details Panel */}
      {selectedActivity && (
        <div className="p-4 bg-sandstone/20 border-t border-sandstone/50 animate-fade-in">
          <div className="flex gap-4">
            <img 
              src={selectedActivity.images[0]} 
              alt={selectedActivity.name}
              className="w-20 h-20 rounded-lg object-cover"
            />
            <div className="flex-1">
              <h4 className="font-semibold text-midnight">{selectedActivity.name}</h4>
              <p className="text-sm text-midnight/60 line-clamp-2 mb-2">
                {selectedActivity.description}
              </p>
              <div className="flex items-center gap-4 text-sm text-midnight/60">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {selectedActivity.duration_hours}h
                </span>
                <span className="flex items-center gap-1">
                  <IndianRupee className="w-3.5 h-3.5" />
                  {selectedActivity.cost_inr === 0 ? 'Free' : `₹${selectedActivity.cost_inr}`}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  {selectedActivity.location.address.split(',')[0]}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Activity List */}
      <div className="p-4 border-t border-sandstone/50">
        <h4 className="text-sm font-medium text-midnight/70 mb-3">Route Stops</h4>
        <div className="space-y-2">
          {activities.map((item, index) => (
            <div 
              key={index}
              className={cn(
                "flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-all",
                selectedActivity?.id === item.activity.id 
                  ? "bg-eucalyptus/10" 
                  : "hover:bg-sandstone/30"
              )}
              onClick={() => setSelectedActivity(
                selectedActivity?.id === item.activity.id ? null : item.activity
              )}
            >
              <div 
                className="w-7 h-7 rounded-full flex items-center justify-center text-white text-sm font-bold"
                style={{ backgroundColor: CATEGORY_COLORS[item.activity.category] || '#4FA3A5' }}
              >
                {index + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-midnight text-sm truncate">
                  {item.activity.name}
                </p>
                <p className="text-xs text-midnight/60">
                  {item.scheduledTime} • {item.activity.duration_hours}h
                </p>
              </div>
              <span className="text-xs px-2 py-1 bg-sandstone/50 rounded capitalize">
                {item.timeSlot}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
