import { useState } from 'react';
import { MapPin, Star, Clock, IndianRupee, Filter, X } from 'lucide-react';
import { Activity } from '@/data';
import { cn } from '@/utils/cn';

interface DestinationMapProps {
  activities: Activity[];
  destination: string;
  onActivitySelect?: (activity: Activity) => void;
}

// Destination center coordinates
const DESTINATION_CENTERS: Record<string, { lat: number; lng: number }> = {
  'Goa': { lat: 15.4909, lng: 73.8278 },
  'Manali': { lat: 32.2396, lng: 77.1887 },
  'Pune': { lat: 18.5204, lng: 73.8567 }
};

// Category colors and icons
const CATEGORY_CONFIG: Record<string, { color: string; label: string }> = {
  leisure: { color: '#4FA3A5', label: 'Leisure' },
  cultural: { color: '#8B5CF6', label: 'Cultural' },
  adventure: { color: '#E07A5F', label: 'Adventure' },
  wellness: { color: '#10B981', label: 'Wellness' },
  wildlife: { color: '#F59E0B', label: 'Wildlife' },
  shopping: { color: '#EC4899', label: 'Shopping' },
  nightlife: { color: '#6366F1', label: 'Nightlife' },
};

export function DestinationMap({ activities, destination, onActivitySelect }: DestinationMapProps) {
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  
  const center = DESTINATION_CENTERS[destination] || DESTINATION_CENTERS['Goa'];
  
  // Get unique categories
  const categories = [...new Set(activities.map(a => a.category))];
  
  // Filter activities
  const filteredActivities = categoryFilter 
    ? activities.filter(a => a.category === categoryFilter)
    : activities;

  const handleActivityClick = (activity: Activity) => {
    setSelectedActivity(activity);
    onActivitySelect?.(activity);
  };

  return (
    <div className="bg-white rounded-2xl border border-sandstone/50 overflow-hidden">
      {/* Map Header with Filters */}
      <div className="p-4 border-b border-sandstone/50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-eucalyptus/10 rounded-lg flex items-center justify-center">
              <MapPin className="w-4 h-4 text-eucalyptus" />
            </div>
            <div>
              <h3 className="font-semibold text-midnight" style={{ fontFamily: 'var(--font-heading)' }}>
                {destination} Experiences Map
              </h3>
              <p className="text-sm text-midnight/60">
                {filteredActivities.length} places to explore
              </p>
            </div>
          </div>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
              showFilters || categoryFilter
                ? "bg-eucalyptus text-white"
                : "bg-sandstone/50 text-midnight hover:bg-sandstone"
            )}
          >
            <Filter className="w-4 h-4" />
            Filter
            {categoryFilter && (
              <span className="w-5 h-5 bg-white text-eucalyptus rounded-full flex items-center justify-center text-xs">
                1
              </span>
            )}
          </button>
        </div>
        
        {/* Filter Pills */}
        {showFilters && (
          <div className="flex flex-wrap gap-2 pt-3 border-t border-sandstone/50 animate-fade-in">
            <button
              onClick={() => setCategoryFilter(null)}
              className={cn(
                "px-3 py-1.5 rounded-full text-sm font-medium transition-colors",
                !categoryFilter
                  ? "bg-midnight text-white"
                  : "bg-sandstone/50 text-midnight hover:bg-sandstone"
              )}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat === categoryFilter ? null : cat)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-1.5",
                  categoryFilter === cat
                    ? "text-white"
                    : "bg-sandstone/50 text-midnight hover:bg-sandstone"
                )}
                style={{
                  backgroundColor: categoryFilter === cat ? CATEGORY_CONFIG[cat]?.color : undefined
                }}
              >
                <div 
                  className="w-2 h-2 rounded-full"
                  style={{ 
                    backgroundColor: categoryFilter === cat ? 'white' : CATEGORY_CONFIG[cat]?.color 
                  }}
                />
                {CATEGORY_CONFIG[cat]?.label || cat}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Map Visualization */}
      <div 
        className="relative w-full h-[500px] bg-gradient-to-br from-pearl to-sandstone/30"
      >
        {/* Map Background Grid */}
        <div className="absolute inset-0" style={{
          backgroundImage: `
            radial-gradient(circle at 20% 30%, rgba(79, 163, 165, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 70%, rgba(230, 225, 216, 0.5) 0%, transparent 50%),
            linear-gradient(rgba(79, 163, 165, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(79, 163, 165, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 100% 100%, 30px 30px, 30px 30px'
        }} />
        
        {/* Destination Label */}
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-sm">
          <p className="text-sm font-medium text-midnight">{destination}</p>
          <p className="text-xs text-midnight/60">
            {center.lat.toFixed(4)}°N, {center.lng.toFixed(4)}°E
          </p>
        </div>
        
        {/* Activity Markers */}
        <div className="absolute inset-8 flex items-center justify-center">
          <div className="relative w-full h-full">
            {filteredActivities.map((activity, index) => {
              // Distribute markers in a grid-like pattern
              const cols = Math.ceil(Math.sqrt(filteredActivities.length));
              const row = Math.floor(index / cols);
              const col = index % cols;
              const x = ((col + 0.5) / cols) * 100;
              const y = ((row + 0.5) / Math.ceil(filteredActivities.length / cols)) * 100;
              
              // Add some randomization for natural look
              const offsetX = (Math.sin(index * 1.5) * 10);
              const offsetY = (Math.cos(index * 1.5) * 10);
              
              const isSelected = selectedActivity?.id === activity.id;
              
              return (
                <div
                  key={activity.id}
                  className={cn(
                    "absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 z-10",
                    isSelected ? "z-20 scale-125" : "hover:scale-110"
                  )}
                  style={{ 
                    left: `${Math.max(10, Math.min(90, x + offsetX))}%`, 
                    top: `${Math.max(10, Math.min(90, y + offsetY))}%`,
                  }}
                  onClick={() => handleActivityClick(activity)}
                >
                  {/* Marker Pin */}
                  <div className="relative">
                    <div 
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 transition-all",
                        isSelected ? "border-white w-10 h-10" : "border-white/80"
                      )}
                      style={{ 
                        backgroundColor: CATEGORY_CONFIG[activity.category]?.color || '#4FA3A5'
                      }}
                    >
                      <MapPin className={cn("text-white", isSelected ? "w-5 h-5" : "w-4 h-4")} />
                    </div>
                    {/* Pulse effect for selected */}
                    {isSelected && (
                      <div 
                        className="absolute inset-0 rounded-full animate-ping opacity-30"
                        style={{ 
                          backgroundColor: CATEGORY_CONFIG[activity.category]?.color || '#4FA3A5'
                        }}
                      />
                    )}
                  </div>
                  
                  {/* Hover tooltip */}
                  {!isSelected && (
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 pointer-events-none">
                      <div className="bg-midnight text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                        {activity.name}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-sm">
          <p className="text-xs font-medium text-midnight/70 mb-2">Categories</p>
          <div className="grid grid-cols-2 gap-1.5">
            {Object.entries(CATEGORY_CONFIG).slice(0, 6).map(([key, config]) => (
              <div key={key} className="flex items-center gap-1.5">
                <div 
                  className="w-2.5 h-2.5 rounded-full" 
                  style={{ backgroundColor: config.color }}
                />
                <span className="text-xs text-midnight/60">{config.label}</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Zoom Controls (visual only) */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-1">
          <button className="w-8 h-8 bg-white rounded-lg shadow-sm flex items-center justify-center text-midnight hover:bg-sandstone transition-colors">
            +
          </button>
          <button className="w-8 h-8 bg-white rounded-lg shadow-sm flex items-center justify-center text-midnight hover:bg-sandstone transition-colors">
            −
          </button>
        </div>
      </div>
      
      {/* Selected Activity Details */}
      {selectedActivity && (
        <div className="p-4 bg-sandstone/20 border-t border-sandstone/50 animate-fade-in">
          <div className="flex gap-4">
            <img 
              src={selectedActivity.images[0]} 
              alt={selectedActivity.name}
              className="w-24 h-24 rounded-xl object-cover"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span 
                    className="inline-block px-2 py-0.5 rounded text-xs font-medium text-white mb-1"
                    style={{ backgroundColor: CATEGORY_CONFIG[selectedActivity.category]?.color }}
                  >
                    {CATEGORY_CONFIG[selectedActivity.category]?.label || selectedActivity.category}
                  </span>
                  <h4 className="font-semibold text-midnight">{selectedActivity.name}</h4>
                </div>
                <button 
                  onClick={() => setSelectedActivity(null)}
                  className="p-1 hover:bg-sandstone rounded-lg transition-colors"
                >
                  <X className="w-4 h-4 text-midnight/40" />
                </button>
              </div>
              <p className="text-sm text-midnight/60 line-clamp-2 mt-1">
                {selectedActivity.description}
              </p>
              <div className="flex items-center gap-4 mt-2 text-sm">
                <span className="flex items-center gap-1 text-midnight/60">
                  <Star className="w-3.5 h-3.5 text-amber-500" />
                  {selectedActivity.user_rating}
                </span>
                <span className="flex items-center gap-1 text-midnight/60">
                  <Clock className="w-3.5 h-3.5" />
                  {selectedActivity.duration_hours}h
                </span>
                <span className="flex items-center gap-1 text-midnight/60">
                  <IndianRupee className="w-3.5 h-3.5" />
                  {selectedActivity.cost_inr === 0 ? 'Free' : `₹${selectedActivity.cost_inr}`}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {selectedActivity.experiential_tags.slice(0, 4).map((tag, i) => (
                  <span 
                    key={i}
                    className="px-2 py-0.5 bg-white rounded text-xs text-midnight/60"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
